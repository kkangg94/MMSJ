import EventrBenner from "./EventBenner";
import EventDetail from "./eventDetail";
import Footer from "./Footer";
import Header from "./Header";
const productEvent = () => {
    return (
        <>
            <Header />
            <EventrBenner />
            <EventDetail />
            <Footer />
        </>
    );
};

export default productEvent;
