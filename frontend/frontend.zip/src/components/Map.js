import React from "react";

export default function Map() {
  return (
    <>
      <iframe
        style={{ width: "600px", height: "500px" }}
        src="https://maps.google.com/maps?q=%EC%84%9C%EC%9A%B8%ED%8A%B9%EB%B3%84%EC%8B%9C%20%EB%A7%88%ED%8F%AC%EA%B5%AC%20%EB%8F%84%ED%99%942%EA%B8%B8%2053&t=&z=17&ie=UTF8&iwloc=&output=embed"
        frameborder="0"
        scrolling="no"
        marginheight="0"
        marginwidth="0"
      ></iframe>
    </>
  );
}
