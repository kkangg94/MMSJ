import React from "react";

export default function Footer() {
  return (
    <div>
      <footer className="footer">
        <p>
          사업자등록번호 : 201-81-21515 주식회사 에스씨케이컴퍼니 대표이사 : 송
          데이비드 호섭 TEL : 1522-3232 개인정보 책임자 : 이현수
        </p>
        <p>All right reserved.</p>
      </footer>
    </div>
  );
}
